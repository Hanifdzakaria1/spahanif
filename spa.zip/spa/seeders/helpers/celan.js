import Booking from "../../models/BookingRuangan.js";
import Feedback from "../../models/FeedbackPengunjung.js";
import Inventaris from "../../models/Inventaris.js";
import Jabatan from "../../models/JabatanStaf.js";
import Layanan from "../../models/Layanan.js";
import MemberShip from "../../models/Membership.js";
import Pembayaran from "../../models/Pembayaran.js";
import Pengunjung from "../../models/Pengunjung.js";
import Ruangan from "../../models/Ruangan.js";
import Staf from "../../models/Staf.js";

export default async function clean() {
    await Booking.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await Feedback.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await Inventaris.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await Jabatan.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await Layanan.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await MemberShip.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await Pembayaran.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await Pengunjung.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await Ruangan.destroy({
        where: {},
        force: true,
        cascade: true
    });
    await Staf.destroy({
        where: {},
        force: true,
        cascade: true
    });
}














