
import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Staf from "./Staf.js";

const Jabatan = db.define(
    "Jabatan",
    {
        idJabatan: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        namaJabatan: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        deskripsiJabatan: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    },
    {
        tableName: "Jabatan",
    },
);
Jabatan.hasMany( Staf, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Staf.belongsTo( Jabatan, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});

export default Jabatan;