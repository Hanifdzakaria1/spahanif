import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Pengunjung from "./Pengunjung.js";
import Pembayaran from "./Pembayaran.js";

const Layanan = db.define(
    "Pengunjung",
    {
        idLayanan: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        namaLayanan: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        deskripsiLayanan: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        hargaLayanan: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        durasiLayana: {
            type: DataTypes.TIME,
            allowNull: false,
        },
    },
    {
        tableName: "Pengunjung",
    },
);
Layanan.hasMany( Pengunjung, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Pengunjung.belongsTo( Layanan, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Staf.hasMany( Layanan, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Layanan.hasMany( Staf, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Pembayaran.belongsTo( Layanan, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Layanan.belongsTo( Pembayaran, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default Layanan;