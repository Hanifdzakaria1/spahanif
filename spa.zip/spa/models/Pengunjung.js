import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Layanan from "./Layanan.js";
import Staf from "./Staf.js";
import MemberShip from "./Membership.js";

const Pengunjung = db.define(
    "Pengunjung",
    {
        idPengunjung: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        namaPengunjung: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
        },

    },
    {
        tableName: "Pengunjung",
    },
);
Layanan.hasMany( Pengunjung, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Pengunjung.belongsTo( Layanan, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


MemberShip.hasMany( Pengunjung, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Pengunjung.belongsTo( MemberShip, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Pengunjung.hasMany( Staf, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Staf.belongsTo( Pengunjung, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default Pengunjung;