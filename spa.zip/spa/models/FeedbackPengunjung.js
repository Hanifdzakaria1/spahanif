
import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Pengunjung from "./Pengunjung.js";


const Feedback = db.define(
    "Feedback",
    {
        idFeedback: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        idPengunjung: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
        },
        idLayanan: {
            type: DataTypes.INTEGER,
            // primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        komentar: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
    },
    {
        tableName: "Feedback",
    },
);
Feedback.hasMany( Pengunjung, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Pengunjung.belongsTo( Feedback, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default Feedback;