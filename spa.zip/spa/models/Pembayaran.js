import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Layanan from "./Layanan.js";
import Pengunjung from "./Pengunjung.js";
// import Pembayaran from "./";

const Pembayaran = db.define(
    "Pembayaran",
    {
        idPembayaran: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        jumlahPembayaran: {
            type: DataType.INTEGER,
            allowNull: false,
        },
    },
    {
        tableName: "Pembayaran",
    },
);
Pembayaran.belongsTo( Layanan, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Layanan.belongsTo( Pembayaran, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Pembayaran.hasMany( Pengunjung, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Pengunjung.hasMany( Pembayaran, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default Pembayaran;