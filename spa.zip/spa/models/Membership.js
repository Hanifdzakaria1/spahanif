import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Pengunjung from "./Pengunjung.js";

const MemberShip = db.define(
    "MemberShip",
    {
        idMemberShip: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        idPengunjung: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
        },
        namaMemberShip: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        deskripsiMemberShip: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        hargaMemberShip: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        durasiMemberShip: {
            type: DataTypes.TIME,
            allowNull: false,
        },
    },
    {
        tableName: "MemberShip",
    },
);
MemberShip.hasMany( Pengunjung, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Pengunjung.belongsTo( MemberShip, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default MemberShip;