import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Jabatan from "./JabatanStaf.js";
import Layanan from "./Layanan.js";
import Ruangan from "./Ruangan.js"
import Pengunjung from "./Pengunjung.js";
import Pembayaran from "./Pembayaran.js";

const Staf = db.define(
    "Staf",
    {
        idStaf: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        namaStaf: {
            type: DataTypes.STRING,
   
            allowNull: false,
        },
        emailStaf: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        namaJabatan: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    },
    {
        tableName: "Staf",
    },
);
Jabatan.hasMany( Staf, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Staf.belongsTo( Jabatan, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Staf.hasMany( Layanan, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Layanan.hasMany( Staf, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Ruangan.hasMany( Staf, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Staf.belongsTo( Ruangan, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Pengunjung.hasMany( Staf, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Staf.belongsTo( Pengunjung, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Gaji.hasMany( Staf, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Staf.belongsTo( Gaji, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});

// Pembayaran.hasMany( Staf, {
//     // foreignKey: "UserId",
//     onDelete: "CASCADE",
//     onUpdate: "CASCADE",
// });
// Staf.belongsTo( Pembayaran, {
//     // foreignKey: "UserId",
//     onDelete: "CASCADE",
//     onUpdate: "CASCADE",
// });
export default Staf;