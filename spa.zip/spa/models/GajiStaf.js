import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
// import Pengunjung from "./Pengunjung.js";
import Staf from "./Staf.js";

const Gaji = db.define(
    "Ruangan",
    {
        idGaji: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        nominalGaji: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
    },
    {
        tableName: "Gaji",
    },
);
Gaji.hasMany( Staf, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Staf.belongsTo( Gaji, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default Gaji;