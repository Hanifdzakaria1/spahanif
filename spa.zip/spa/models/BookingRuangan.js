
import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Pengunjung from "./Pengunjung.js";

const Booking = db.define(
    "Booking",
    {
        idBooking: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        idPengunjung: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
        },
        idRuangan: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
        },
        tglBooking: {
            type: DataTypes.TIME,
            allowNull: false,
        },
        statusBooking: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
    },
    {
        tableName: "Booking",
    },
);
Booking.hasMany( Pengunjung, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Pengunjung.belongsTo( Booking, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


export default Booking;