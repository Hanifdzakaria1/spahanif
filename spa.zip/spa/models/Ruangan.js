import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Pengunjung from "./Pengunjung.js";
import Staf from "./Staf.js";

const Ruangan = db.define(
    "Ruangan",
    {
        idRuangan: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        noRuangan: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        kapasitasRuangan: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        deskripsiRuangan: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    },
    {
        tableName: "Ruangan",
    },
);
Ruangan.hasMany( Pengunjung, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Pengunjung.belongsTo( Ruangan, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});


Ruangan.hasMany( Staf, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Staf.belongsTo( Ruangan, {
    // foreignKey: "UserId",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default Ruangan;