
import { DataTypes } from "sequelize";
import db from "../utils/connection.js";
import Ruangan from "./Ruangan.js";

const Inventaris = db.define(
    "Inventaris",
    {
        idInventaris: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        namaInventaris: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        ukuranInventaris: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
    },
    {
        tableName: "Inventaris",
    },
);
Ruangan.hasMany( Inventaris, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
Inventaris.hasMany( Inventaris, {
    // foreignKey: "Id",
    onDelete: "CASCADE",
    onUpdate: "CASCADE",
});
export default Inventaris;